﻿// <copyright file="FundingResource.cs" company="TECO Services Inc.">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <authors>Enterprise & Business Solutions</authors>
// <date>2017-11-27</date>

namespace TECO.CSSP.Portal.Web.Areas.AgencyPortal.Models.Commitment
{
    /// <summary>
    /// Look-up entity to describe the list of FundingResource
    /// </summary>
    public enum FundingResource
    {
        /// <summary>
        /// Represents enumeration for EHEAP
        /// </summary>
        EEHEAP,

        /// <summary>
        /// Represents enumeration for LiHeap
        /// </summary>
        LIHeap,

        /// <summary>
        /// Represents enumeration for EFSP
        /// </summary>
        EFSP,

        /// <summary>
        /// Represents enumeration for CSBG
        /// </summary>
        CSBG,

        /// <summary>
        /// Represents enumeration for SSVF
        /// </summary>
        SSVF,

        /// <summary>
        /// Represents enumeration for Share
        /// </summary>
        Share,

        /// <summary>
        /// Represents enumeration for Ship
        /// </summary>
        Ship,

        /// <summary>
        /// Represents enumeration for TBRA
        /// </summary>
        TBRA,

        /// <summary>
        /// Represents enumeration for Other
        /// </summary>
        Other
    }
}