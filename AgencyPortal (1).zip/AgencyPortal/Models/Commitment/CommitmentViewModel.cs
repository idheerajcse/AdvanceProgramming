﻿// <copyright file="CommitmentViewModel.cs" company="TECO Services Inc.">
// Copyright (c) 2016 All Rights Reserved
// </copyright>
// <authors>Enterprise & Business Solutions</authors>
// <date>2017-11-20</date>
namespace TECO.CSSP.Portal.Web.Areas.AgencyPortal.Models.Commitment
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using TECO.CSSP.Portal.Web.Areas.AgencyPortal.Models.ContractAccount;

    /// <summary>
    /// View model for Commitment
    /// </summary>
    public class CommitmentViewModel
    {
        #region Fields

        /// <summary>
        /// The preferences
        /// </summary>
        public IList<FundingResource> fundingResources = new List<FundingResource>();

        #endregion Fields

        #region Properties

        /// <summary>
        /// Gets or sets the agency memo value.
        /// </summary>
        public string AgencyMemo { get; set; }

        /// <summary>
        /// Gets or sets the agent first name.
        /// </summary>
        public string AgentFirstName { get; set; }

        /// <summary>
        /// Gets or sets the agent last name.
        /// </summary>
        public string AgentLastName { get; set; }

        /// <summary>
        /// Gets or sets the agent phone number.
        /// </summary>
        public string AgentPhoneNumber { get; set; }

        /// <summary>
        /// Gets or sets the business partner name.
        /// </summary>
        public string BusinessPartnerName { get; set; }

        /// <summary>
        /// Gets or sets the case name.
        /// </summary>
        public string CaseName { get; set; }

        /// <summary>
        /// Gets or sets the contract account number.
        /// </summary>
        public string ContractAccountNumber { get; set; }

        /// <summary>
        /// Gets or sets the contract account number.
        /// </summary>
        public ContractAccountDetailViewModel ContractAccount { get; set; }

        /// <summary>
        /// Gets or sets Current Date.
        /// </summary>
        public DateTime CurrentDate { get; set; }

        /// <summary>
        /// Gets the list of funding source view model.
        /// </summary>
        /// <summary>
        /// Gets the preferences.
        /// </summary>
        /// <value>
        /// The preferences.
        /// </value>
        public IList<FundingResource> FundingResources
        {
            get { return this.fundingResources; }
        }

        /// <summary>
        /// Gets or sets the phone number.
        /// </summary>
        public string PhoneNumber { get; set; }

        /// <summary>
        /// Gets or sets the list of funding source view model.
        /// </summary>
        public FundingResource SelectedFundingSource { get; set; }

        /// <summary>
        /// Gets or sets the service address.
        /// </summary>
        public string ServiceAddress { get; set; }

        /// <summary>
        /// Gets or sets the additional amount.
        /// </summary>
        public string AdditionalAmount { get; set; }

        /// <summary>
        /// Gets or sets the total payment.
        /// </summary>
        public string TotalPayment { get; set; }

        #endregion Properties
    }
}