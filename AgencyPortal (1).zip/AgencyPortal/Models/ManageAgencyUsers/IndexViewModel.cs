﻿// <copyright file="IndexViewModel.cs" company="TECO Services Inc.">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <authors>Enterprise & Business Solutions</authors>
// <date>2017-10-16</date>
namespace TECO.CSSP.Portal.Web.Areas.AgencyPortal.Models.ManageAgencyUsers
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.Linq;
    using Common;
    using Common.Mvc.ViewModel;
    using Common.Security;
    using Domain.Identity;
    using Extensions;

    /// <summary>
    /// The model for the Index page
    /// </summary>
    public class IndexViewModel : TableViewModelBase
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="IndexViewModel"/> class.
        /// </summary>
        public IndexViewModel()
        {
            Columns.Add(new ColumnDefinition() { FieldName = "FullName", SortField = "LastName", HeaderLabel = "Name" });
            Columns.Add(new ColumnDefinition() { FieldName = "UserName", IsUniqueId = true, IsDefaultSort = true, IsSortable = true,  HeaderLabel = "Username" });
            Columns.Add(new ColumnDefinition() { FieldName = "Email", IsSortable = true, HeaderLabel = "Email" });
            Columns.Add(new ColumnDefinition() { FieldName = "LastLogin", IsSortable = true,  HeaderLabel = "Last Login" });
            Columns.Add(new ColumnDefinition() { FieldName = "CreatedDate", IsSortable = true,  HeaderLabel = "Created Date" });
            
            IsSelectable = true;
            ShowPagination = true;
        }

        #endregion Constructors

        #region Properties

        /// <summary>
        /// Gets or sets the created.
        /// </summary>
        /// <value>
        /// The created.
        /// </value>
        [Display(Name = "Filter_Label_Created", ResourceType = typeof(Resource.AgencyPortal.ManageAgencyUsers.Index.Strings))]
        public FriendlyDateRange Created { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this <see cref="IndexViewModel"/> is enabled.
        /// </summary>
        /// <value>
        ///   <c>true</c> if enabled; otherwise, <c>false</c>.
        /// </value>
        public bool Enabled { get; set; }

        /// <summary>
        /// Gets or sets the last login.
        /// </summary>
        /// <value>
        /// The last login.
        /// </value>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1726:UsePreferredTerms", MessageId = "Login", Justification = "Per Design")]
        [Display(Name = "Filter_Label_LastLogin", ResourceType = typeof(Resource.AgencyPortal.ManageAgencyUsers.Index.Strings))]
        public FriendlyDateRange LastLogin { get; set; }

        /// <summary>
        /// Gets or sets the search string.
        /// </summary>
        /// <value>
        /// The search string.
        /// </value>
        [Display(Name = "Filter_Label_SearchString", ResourceType = typeof(Resource.AgencyPortal.ManageAgencyUsers.Index.Strings))]
        public string SearchString { get; set; }

        /// <summary>
        /// Processes the filter.
        /// </summary>
        /// <param name="query">The query.</param>
        /// <returns>modified query</returns>
        public IQueryable<ApplicationUser> ProcessFilter(IQueryable<ApplicationUser> query)
        {
            Validate.NotNull(query);

            var lastLoginDate = LastLogin.ToDateFromRange();
            var createdDate = Created.ToDateFromRange();

            if (!string.IsNullOrEmpty(SearchString))
            {
                query = query.Where(x => x.UserName.ToLower().Contains(SearchString.ToLower()) || x.Email.ToLower().Contains(SearchString.ToLower()) || x.FirstName.ToLower().Contains(SearchString.ToLower()) || x.LastName.ToLower().Contains(SearchString.ToLower()));
            }

            switch (LastLogin)
            {
                case FriendlyDateRange.AllTime:
                    {
                        break;
                    }

                case FriendlyDateRange.None:
                    {
                        query = query.Where(x => x.LastLogin == lastLoginDate);
                        break;
                    }

                default:
                    {
                        query = query.Where(x => x.LastLogin >= lastLoginDate);
                        break;
                    }
            }

            switch (Created)
            {
                case FriendlyDateRange.AllTime:
                    {
                        break;
                    }

                case FriendlyDateRange.None:
                    {
                        query = query.Where(x => x.CreatedDate == createdDate);
                        break;
                    }

                default:
                    {
                        query = query.Where(x => x.CreatedDate >= createdDate);
                        break;
                    }
            }

            return query;
        }

        #endregion Properties
    }
}