﻿// <copyright file="FriendlyDateRange.cs" company="TECO Services Inc.">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <authors>Enterprise & Business Solutions</authors>
// <date>2017-10-16</date>
namespace TECO.CSSP.Portal.Web.Areas.AgencyPortal.Models.ManageAgencyUsers
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Linq;
    using System.Web;

    /// <summary>
    /// Friendly Date Ranges
    /// </summary>
    public enum FriendlyDateRange
    {
        /// <summary>
        /// All time
        /// </summary>
        [Display(Name = "Enum_FriendlyDateRange_Label_All", ResourceType = typeof(Resource.Common.UI))]
        AllTime,

        /// <summary>
        /// The within last day
        /// </summary>
        [Display(Name = "Enum_FriendlyDateRange_Label_LastDay", ResourceType = typeof(Resource.Common.UI))]
        WithinLastDay,

        /// <summary>
        /// The within last week
        /// </summary>
        [Display(Name = "Enum_FriendlyDateRange_Label_LastWeek", ResourceType = typeof(Resource.Common.UI))]
        WithinLastWeek,

        /// <summary>
        /// The within last month
        /// </summary>
        [Display(Name = "Enum_FriendlyDateRange_Label_LastMonth", ResourceType = typeof(Resource.Common.UI))]
        WithinLastMonth,

        /// <summary>
        /// The within last3 months
        /// </summary>
        [Display(Name = "Enum_FriendlyDateRange_Label_3Months", ResourceType = typeof(Resource.Common.UI))]
        WithinLast3Months,

        /// <summary>
        /// The within last year
        /// </summary>
        [Display(Name = "Enum_FriendlyDateRange_Label_LastYear", ResourceType = typeof(Resource.Common.UI))]
        WithinLastYear,

        /// <summary>
        /// The none
        /// </summary>
        [Display(Name = "Enum_FriendlyDateRange_Label_None", ResourceType = typeof(Resource.Common.UI))]
        None
    }
}