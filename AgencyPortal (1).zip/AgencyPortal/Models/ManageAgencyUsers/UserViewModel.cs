﻿// <copyright file="UserViewModel.cs" company="TECO Services Inc.">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <authors>Enterprise & Business Solutions</authors>
// <date>2017-10-16</date>
namespace TECO.CSSP.Portal.Web.Areas.AgencyPortal.Models.ManageAgencyUsers
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using Common.Mvc.ViewModel;
    using Web.Models.Shared;

    /// <summary>
    /// The User View Model
    /// </summary>
    public class UserViewModel : ViewModelBase
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="UserViewModel"/> class.
        /// </summary>
        public UserViewModel()
        {
            EmailAddressTemplate = new EmailAddress() { IsRequired = true };
            PhoneNumberTemplate = new PhoneNumber() { IsRequired = true };
        }

        #endregion Constructors

        #region Properties
        
        /// <summary>
        /// Gets or sets the user identifier.
        /// </summary>
        /// <value>
        /// The user identifier.
        /// </value>
        public string UserId { get; set; }

        /// <summary>
        /// Gets or sets the created date.
        /// </summary>
        /// <value>
        /// The created date.
        /// </value>
        public DateTime CreatedDate { get; set; }

        /// <summary>
        /// Gets or sets the first name.
        /// </summary>
        /// <value>
        /// The first name.
        /// </value>
        [Required]
        public string FirstName { get; set; }

        /// <summary>
        /// Gets or sets the last login.
        /// </summary>
        /// <value>
        /// The last login.
        /// </value>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1726:UsePreferredTerms", MessageId = "Login", Justification = "As per design")]
        public DateTime? LastLogin { get; set; }

        /// <summary>
        /// Gets or sets the last name.
        /// </summary>
        /// <value>
        /// The last name.
        /// </value>
        [Required]
        public string LastName { get; set; }

        /// <summary>
        /// Gets or sets the phone number template.
        /// </summary>
        /// <value>
        /// The phone number template.
        /// </value>
        public PhoneNumber PhoneNumberTemplate { get; set; }

        /// <summary>
        /// Gets or sets the phone number.
        /// </summary>
        /// <value>
        /// The phone number.
        /// </value>
        public string PhoneNumber
        {
            get
            {
                return PhoneNumberTemplate.Value;
            }

            set
            {
                PhoneNumberTemplate.Value = value;
            }
        }

        /// <summary>
        /// Gets or sets the email address template.
        /// </summary>
        /// <value>
        /// The email address template.
        /// </value>
        public EmailAddress EmailAddressTemplate { get; set; }

        /// <summary>
        /// Gets or sets the email.
        /// </summary>
        /// <value>
        /// The email.
        /// </value>
        public string Email
        {
            get
            {
                return EmailAddressTemplate.Value;
            }

            set
            {
                EmailAddressTemplate.Value = value;
            }
        }

        /// <summary>
        /// Gets or sets the name of the user.
        /// </summary>
        /// <value>
        /// The name of the user.
        /// </value>
        public string UserName { get; set; }

        /// <summary>
        /// Gets or sets the full name.
        /// </summary>
        /// <value>
        /// The full name.
        /// </value>
        public string FullName { get; set; }

        /// <summary>
        /// Gets or sets modified by.
        /// </summary>
        /// <value>
        /// The modified by name.
        /// </value>
        [MaxLength(50)]
        public string ModifiedBy { get; set; }

        /// <summary>
        /// Gets or sets the modified date.
        /// </summary>
        /// <value>
        /// The modified date.
        /// </value>
        public DateTime? ModifiedDate { get; set; }

        /// <summary>
        /// Gets or sets the selected identifier.
        /// </summary>
        /// <value>
        /// The selected identifier.
        /// </value>
        public string SelectedId { get; set; }

        #endregion Properties
    }
}