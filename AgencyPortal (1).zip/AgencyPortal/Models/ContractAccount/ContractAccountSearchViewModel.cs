﻿// <copyright file="ContractAccountSearchViewModel.cs" company="TECO Services Inc.">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <authors>Enterprise & Business Solutions</authors>
// <date>2017-10-27</date>
namespace TECO.CSSP.Portal.Web.Areas.AgencyPortal.Models.ContractAccount
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using Common.Mvc.ViewModel;
    using Common.Validation;
    using Domain.BusinessMasterData;
    using Resource;
    using TECO.Common.Text.RegularExpressions;
    using TECO.CSSP.Portal.Resource.Common;
    using TECO.CSSP.Portal.Web.Models.Shared;

    /// <summary>
    /// View model for contract account search of Agency Portal.
    /// </summary>
    public class ContractAccountSearchViewModel : ViewModelBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ContractAccountSearchViewModel"/> class.
        /// </summary>
        public ContractAccountSearchViewModel()
        {
            MaintenanceWindows = new MaintenanceWindowViewModel();
        }

        /// <summary>
        /// Gets the current balance due.
        /// </summary>
        [UIHint(Resource.Common.Constants.CurrencyUIHint)]
        public decimal CurrentBalance { get; internal set; }

        /// <summary>
        /// Gets the current balance due date.
        /// </summary>
        [DisplayFormat(DataFormatString = "{0:dd MMM yyyy}")]
        public DateTime? CurrentBalanceDueDate { get; internal set; }

        /// <summary>
        /// Gets Description
        /// </summary>
        public string Description { get; internal set; }

        /// <summary>
        /// Gets or sets the maintenance windows.
        /// </summary>
        /// <value>
        /// The maintenance windows.
        /// </value>
        public MaintenanceWindowViewModel MaintenanceWindows { get; set; }
    }
}