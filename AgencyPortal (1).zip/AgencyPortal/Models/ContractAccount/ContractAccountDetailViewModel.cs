﻿// <copyright file="ContractAccountDetailViewModel.cs" company="TECO Services Inc.">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <authors>Enterprise & Business Solutions</authors>
// <date>2017-11-2</date>
namespace TECO.CSSP.Portal.Web.Areas.AgencyPortal.Models.ContractAccount
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using Common.Mvc.ViewModel;
    using Common.Validation;
    using Domain.BusinessMasterData;
    using Resource;
    using TECO.Common.Text.RegularExpressions;
    using TECO.CSSP.Portal.Resource.Common;
    using TECO.CSSP.Portal.Web.Models.Shared;

    /// <summary>
    /// View model for contract account detail of Agency Portal.
    /// </summary>
    public class ContractAccountDetailViewModel 
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="ContractAccountDetailViewModel"/> class.
        /// </summary>
        public ContractAccountDetailViewModel()
        {
        }

        #endregion Constructors

        #region Properties
        /// <summary>
        /// Gets or sets the code.
        /// </summary>
        /// <value>
        /// The code.
        /// </value>       
        public Guid ContractId { get; set; }

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>
        /// The name.
        /// </value>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the account no.
        /// </summary>
        /// <value>
        /// The account no.
        /// </value>
        public string AccountNo { get; set; }

        /// <summary>
        /// Gets or sets the address.
        /// </summary>
        /// <value>
        /// The address.
        /// </value>
        public string Address { get; set; }

        /// <summary>
        /// Gets or sets the total amount due.
        /// </summary>
        /// <value>
        /// The total amount due.
        /// </value>
        [DisplayFormat(DataFormatString = "{#,##0.00}")]
        public decimal TotalAmountDue { get; set; }

        /// <summary>
        /// Gets or sets the current month charges due.
        /// </summary>
        /// <value>
        /// The current month charges.
        /// </value>
        public DateTime CurrentMonthChargesDue { get; set; }

        /// <summary>
        /// Gets or sets the OpenItemsViewModel.
        /// </summary>
        /// <value>
        /// The OpenItemsViewModel.
        /// </value>
        public OpenItemsViewModel OpenItemsViewModel { get; set; }

        /// <summary>
        /// Gets or sets the ContractAccountId.
        /// </summary>
        /// <value>
        /// The ContractAccountId.
        /// </value>       
        public string ContractAccountId { get; set; }

        /// <summary>
        /// Gets or sets the PhoneNumber.
        /// </summary>
        /// <value>
        /// The CPhoneNumber.
        /// </value>       
        public string PhoneNumber { get; set; }

        /// <summary>
        /// Gets or sets the ServiceAddress.
        /// </summary>
        /// <value>
        /// The ServiceAddress.
        /// </value>       
        public string ServiceAddress { get; set; }

        /// <summary>
        /// Gets or sets the OverPayment.
        /// </summary>
        /// <value>
        /// The OverPayment.
        /// </value>       
        public string OverPayment { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this payment is exceeded.        
        /// </summary>
        /// <value>
        /// The IsOverPay.
        /// </value>       
        public bool IsOverPay { get; set; }

        #endregion Properties
    }
}