﻿// <copyright file="OpenItemsViewModel.cs" company="TECO Services Inc.">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <authors>Enterprise & Business Solutions</authors>
// <date>2017-11-17</date>
namespace TECO.CSSP.Portal.Web.Areas.AgencyPortal.Models.ContractAccount
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using TECO.Common.Mvc.ViewModel;

    /// <summary>
    /// The OpenItems ViewModel
    /// </summary>
    public class OpenItemsViewModel : TableViewModelBase
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="OpenItemsViewModel"/> class.
        /// </summary>
        public OpenItemsViewModel()
        {
            ShowHeaders = true;
            ShowPagination = true;
            IsSelectable = false;
            SortDirection = SortDirection.Descending;
            SortExpression = "FirstName";
            Columns.Add(new ColumnDefinition() { IsSortable = true, FieldName = "DocumentDate", HeaderLabel = "Doc Date", DefaultSortDirection = SortDirection.Descending, });
            Columns.Add(new ColumnDefinition() { IsSortable = true, FieldName = "ChargeDescription", HeaderLabel = "Description" });
            Columns.Add(new ColumnDefinition() { IsSortable = true, FieldName = "DueDate", HeaderLabel = "Due Date" });
            Columns.Add(new ColumnDefinition() { IsSortable = true, FieldName = "OpenAmount", HeaderLabel = "Amount" });
            Columns.Add(new ColumnDefinition() { IsSortable = true, FieldName = "Payable", HeaderLabel = "Payable" });
            Columns.Add(new ColumnDefinition() { IsSortable = false, FieldName = "IndicatorPlan", HeaderLabel = "Indicator Plan" });
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets a value indicating whether this instance is read authorized.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is read authorized; otherwise, <c>false</c>.
        /// </value>
        public bool IsReadAuthorized { get; internal set; }

        /// <summary>
        /// Gets a value indicating whether this instance is create authorized.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is create authorized; otherwise, <c>false</c>.
        /// </value>
        public bool IsCreateAuthorized { get; internal set; }

        /// <summary>
        /// Gets a value indicating whether this instance is delete authorized.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is delete authorized; otherwise, <c>false</c>.
        /// </value>
        public bool IsDeleteAuthorized { get; internal set; }

        #endregion
    }
}