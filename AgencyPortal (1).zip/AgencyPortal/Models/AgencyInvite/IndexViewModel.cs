﻿// <copyright file="IndexViewModel.cs" company="TECO Services Inc.">
// Copyright (c) 2016 All Rights Reserved
// </copyright>
// <authors>Enterprise & Business Solutions</authors>
// <date>2017-9-28</date>
namespace TECO.CSSP.Portal.Web.Areas.AgencyPortal.Models.AgencyInvite
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using TECO.Common.Mvc.ViewModel;
    using TECO.Common.Security;

    /// <summary>
    /// Model for the IndexView
    /// </summary>
    /// <seealso cref="TECO.Common.Mvc.ViewModel.TableViewModelBase" />
    public class IndexViewModel : TableViewModelBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="IndexViewModel"/> class.
        /// </summary>
        public IndexViewModel()
        {
            ShowHeaders = true;
            ShowPagination = true;
            IsSelectable = false;
            SortDirection = SortDirection.Descending;
            SortExpression = "FirstName";
            Columns.Add(new ColumnDefinition() { IsSortable = true, FieldName = "FirstName", HeaderLabel = "First Name", DefaultSortDirection = SortDirection.Descending, });
            Columns.Add(new ColumnDefinition() { IsSortable = true, FieldName = "LastName", HeaderLabel = "Last Name" });
            Columns.Add(new ColumnDefinition() { IsSortable = true, FieldName = "EmailAddress", HeaderLabel = "Email Address" });
            Columns.Add(new ColumnDefinition() { IsSortable = true, FieldName = "CreatedBy", HeaderLabel = "Created By" });
            Columns.Add(new ColumnDefinition() { IsSortable = true, FieldName = "CreatedDate", HeaderLabel = "Created Date" });
            Columns.Add(new ColumnDefinition() { ColumnType = ColumnType.Link, LinkKeyField = "AgencyInviteId", LinkLabel = Resource.Common.Strings.Link_Label_Details, LinkAddress = "AgencyPortal/AgencyInvite/Details/{0}" });
            Columns.Add(new ColumnDefinition() { ColumnType = ColumnType.Link, LinkKeyField = "AgencyInviteId", LinkLabel = Resource.Common.Strings.Link_Label_Delete, LinkAddress = "AgencyPortal/AgencyInvite/Delete/{0}" });
        }

        /// <summary>
        /// Gets a value indicating whether this instance is read authorized.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is read authorized; otherwise, <c>false</c>.
        /// </value>
        public bool IsReadAuthorized { get; internal set; }

        /// <summary>
        /// Gets a value indicating whether this instance is create authorized.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is create authorized; otherwise, <c>false</c>.
        /// </value>
        public bool IsCreateAuthorized { get; internal set; }

        /// <summary>
        /// Gets a value indicating whether this instance is delete authorized.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is delete authorized; otherwise, <c>false</c>.
        /// </value>
        public bool IsDeleteAuthorized { get; internal set; }
    }
}