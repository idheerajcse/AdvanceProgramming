﻿// <copyright file="AgencyInviteViewModel.cs" company="TECO Services Inc.">
// Copyright (c) 2016 All Rights Reserved
// </copyright>
// <authors>Enterprise & Business Solutions</authors>
// <date>2017-10-16</date>
namespace TECO.CSSP.Portal.Web.Areas.AgencyPortal.Models.AgencyInvite
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Linq;
    using System.Web;
    using System.Web.Mvc;
    using Common.Mvc.ViewModel;
    using Resource;
    using TECO.Common.Text.RegularExpressions;
    using TECO.CSSP.Portal.Resource.Common;

    /// <summary>
    /// Model for displaying Agency Invite
    /// </summary>
    public class AgencyInviteViewModel : ViewModelBase
    {
        /// <summary>
        /// Application Role Manager.
        /// </summary>
        private IList<SelectListItem> applicationRoles = new List<SelectListItem>();

        /// <summary>
        /// Gets or sets the AgencyInviteId.
        /// </summary>
        /// <value>
        /// The Agency Invite Id.
        /// </value>
        public Guid AgencyInviteId { get; set; }

        /// <summary>
        /// Gets or sets the AgencyId 
        /// </summary>
        /// <value> The Agency Id.
        /// </value>
        public string AgencyId { get; set; }

        /// <summary>
        /// Gets or sets the EmailAddress.
        /// </summary>
        /// <value>
        /// Email Address.
        /// </value>
        [Required(ErrorMessage = "The email address is required")]
        [EmailAddress]
        public string EmailAddress { get; set; }

        /// <summary>
        /// Gets or sets the FirstName.
        /// </summary>
        /// <value>
        /// First Name.
        /// </value>
        [Required(ErrorMessageResourceName = "Models_Home_ContactAnonymousViewModel_Error_FirstName_Required", ErrorMessageResourceType = typeof(Resources))]
        [StringLength(50, ErrorMessageResourceName = "Common_Error_CharacterLength",
        ErrorMessageResourceType = typeof(Resources), MinimumLength = 1)]
        [RegularExpression(RegexPatterns.Name, ErrorMessageResourceName = "Models_Home_ContactAnonymousViewModel_Error_InvalidFirstname_RegexName",
            ErrorMessageResourceType = typeof(Resources))]
        [Display(Name = "Models_Home_ContactAnonymousViewModel_FirstName_Display", ResourceType = typeof(Resources))]
        public string FirstName { get; set; }

        /// <summary>
        /// Gets or sets the LastName.
        /// </summary>
        /// <value>
        /// Last Name.
        /// </value>
        [Required(ErrorMessageResourceName = "Models_Home_ContactAnonymousViewModel_Error_LastName_Required", ErrorMessageResourceType = typeof(Resources))]
        [StringLength(50, ErrorMessageResourceName = "Common_Error_CharacterLength",
        ErrorMessageResourceType = typeof(Resources), MinimumLength = 1)]
        [RegularExpression(RegexPatterns.Name, ErrorMessageResourceName = "Models_Home_ContactAnonymousViewModel_Error_InvalidLastName_RegexName",
            ErrorMessageResourceType = typeof(Resources))]
        [Display(Name = "Models_Home_ContactAnonymousViewModel_LastName_Display", ResourceType = typeof(Resources))]
        public string LastName { get; set; }

        /// <summary>
        /// Gets or sets Role Id
        /// </summary>
        [Required]
        public string RoleId { get; set; }

        /// <summary>
        /// Gets or sets Role Name
        /// </summary>
        public string RoleName { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether the Point Of Contact.
        /// </summary>
        /// <value>
        /// The Point of contact.
        /// </value>
        public bool PointOfContact { get; set; }

        /// <summary>
        /// Gets or sets CreatedBy
        /// </summary>
        /// <value> Created By </value>
        public string CreatedBy { get; set; }

        /// <summary>
        /// Gets or sets Created Date </summary>
        /// <value> Created Date
        /// </value>
        public DateTime CreatedDate { get; set; }

        /// <summary>
        /// Gets the collection of Agency Invite Roles.
        /// </summary>
        /// <value>
        /// The collection of Agency Invite Roles.
        /// </value>
        public ICollection<SelectListItem> ApplicationRoles
        {
            get
            {
                return this.applicationRoles;
            }
        }
    }
}
