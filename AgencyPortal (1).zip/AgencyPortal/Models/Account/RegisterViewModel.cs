﻿// <copyright file="RegisterViewModel.cs" company="TECO Services Inc.">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <authors>Enterprise & Business Solutions</authors>
// <date>2017-10-20</date>
namespace TECO.CSSP.Portal.Web.Areas.AgencyPortal.Models.Account
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using Common.Mvc.ViewModel;
    using Resource;
    using TECO.Common.Text.RegularExpressions;
    using TECO.CSSP.Portal.Resource.Common;

    /// <summary>
    /// View model for registration of Agency User.
    /// </summary>
    public class RegisterViewModel : ViewModelBase
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="RegisterViewModel"/> class.
        /// </summary>
        public RegisterViewModel()
        {
        }

        #endregion Constructors

        #region Properties

        /// <summary>
        /// Gets or sets the code.
        /// </summary>
        /// <value>
        /// The code.
        /// </value>
        [Required(ErrorMessageResourceName = "Common_Error_Required", ErrorMessageResourceType = typeof(Portal.Resource.Resources))]
        public Guid AgencyInviteId { get; set; }

        /// <summary>
        /// Gets or sets the confirm password.
        /// </summary>
        /// <value>
        /// The confirm password.
        /// </value>
        [Required(ErrorMessageResourceName = "RequiredError", ErrorMessageResourceType = typeof(Resource.Common.Responses))]
        [DataType(DataType.Password)]
        [Display(Name = "Account_RegisterViewModel_ConfirmPassword_Label", ResourceType = typeof(Portal.Resource.Resources))]
        [Compare("Password", ErrorMessageResourceName = "Account_RegisterViewModel_InvalidPasswordConfirmation",
            ErrorMessageResourceType = typeof(Portal.Resource.Resources))]
        public string ConfirmPassword
        {
            get; set;
        }

        /// <summary>
        /// Gets or sets the first name.
        /// </summary>
        /// <value>
        /// The first name.
        /// </value>
        [Required(ErrorMessageResourceName = "Models_Home_ContactAnonymousViewModel_Error_FirstName_Required", ErrorMessageResourceType = typeof(Resources))]
        [StringLength(20, ErrorMessageResourceName = "Common_Error_CharacterLength",
        ErrorMessageResourceType = typeof(Resources), MinimumLength = 1)]
        [RegularExpression(RegexPatterns.Name, ErrorMessageResourceName = "Models_Home_ContactAnonymousViewModel_Error_InvalidFirstname_RegexName",
            ErrorMessageResourceType = typeof(Resources))]
        [Display(Name = "Models_Home_ContactAnonymousViewModel_FirstName_Display", ResourceType = typeof(Resources))]
        public string FirstName { get; set; }

        /// <summary>
        /// Gets or sets the last name.
        /// </summary>
        /// <value>
        /// The last name.
        /// </value>
        [Required(ErrorMessageResourceName = "Models_Home_ContactAnonymousViewModel_Error_LastName_Required", ErrorMessageResourceType = typeof(Resources))]
        [StringLength(20, ErrorMessageResourceName = "Common_Error_CharacterLength",
        ErrorMessageResourceType = typeof(Resources), MinimumLength = 1)]
        [RegularExpression(RegexPatterns.Name, ErrorMessageResourceName = "Models_Home_ContactAnonymousViewModel_Error_InvalidLastName_RegexName",
            ErrorMessageResourceType = typeof(Resources))]
        [Display(Name = "Models_Home_ContactAnonymousViewModel_LastName_Display", ResourceType = typeof(Resources))]
        public string LastName { get; set; }

        /// <summary>
        /// Gets or sets the password.
        /// </summary>
        /// <value>
        /// The password.
        /// </value>
        [Required(ErrorMessageResourceName = "Common_Error_Required", ErrorMessageResourceType = typeof(Portal.Resource.Resources))]
        [StringLength(40, ErrorMessageResourceName = "Account_RegisterViewModel_InvalidPasswordLength",
            ErrorMessageResourceType = typeof(Portal.Resource.Resources), MinimumLength = 8)]
        [RegularExpression(Constants.PasswordRequirement, ErrorMessageResourceName = "PasswordRequirementError", ErrorMessageResourceType = typeof(Resource.Common.Responses))]
        [DataType(DataType.Password)]
        [Display(Name = "Common_Text_Password", ResourceType = typeof(Portal.Resource.Resources))]
        public string Password
        {
            get; set;
        }

        /// <summary>
        /// Gets or sets the phone number.
        /// </summary>
        /// <value>
        /// The phone number.
        /// </value>
        [Required(ErrorMessageResourceName = "Common_Error_Required", ErrorMessageResourceType = typeof(Resources))]
        [Display(Name = "Common_Display_PhoneNumberWithHyphens", ResourceType = typeof(Resources))]
        [DataType(DataType.PhoneNumber, ErrorMessageResourceName = "Common_Error_Invalid", ErrorMessageResourceType = typeof(Resources))]
        [StringLength(12, ErrorMessageResourceName = "Common_Error_PhoneNumberWithHyphenFormat",
            ErrorMessageResourceType = typeof(Resources), MinimumLength = 12)]
        [RegularExpression(RegexPatterns.PhoneNumberWithHyphens, ErrorMessageResourceName = "Common_Error_PhoneNumberWithHyphenFormat",
            ErrorMessageResourceType = typeof(Resources))]
        [Phone]
        public string PhoneNumber { get; set; }

        /// <summary>
        /// Gets or sets the Username.
        /// </summary>
        /// <value>
        /// The username.
        /// </value>
        [Required(ErrorMessageResourceName = "Common_Error_Required", ErrorMessageResourceType = typeof(Portal.Resource.Resources))]
        [StringLength(32, ErrorMessageResourceName = "Common_Error_CharacterLength",
            ErrorMessageResourceType = typeof(Portal.Resource.Resources), MinimumLength = 6)]
        [RegularExpression(RegexPatterns.Alphanumeric, ErrorMessageResourceName = "Common_Error_AlphaNumericRegularExpression",
            ErrorMessageResourceType = typeof(Portal.Resource.Resources))]
        [Display(Name = "Common_Text_UserName", ResourceType = typeof(Portal.Resource.Resources))]
        public string UserName
        {
            get; set;
        }

        #endregion Properties
    }
}