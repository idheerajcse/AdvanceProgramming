﻿// <copyright file="RegisterConfirmationViewModel.cs" company="TECO Services Inc.">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <authors>Enterprise & Business Solutions</authors>
// <date>2017-10-24</date>
namespace TECO.CSSP.Portal.Web.Areas.AgencyPortal.Models.Account
{
    /// <summary>
    /// View model for registration confirmation of Agency User.
    /// </summary>
    public class RegisterConfirmationViewModel
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="RegisterConfirmationViewModel"/> class.
        /// </summary>
        public RegisterConfirmationViewModel()
        {
        }

        #endregion Constructors

        #region Properties

        /// <summary>
        /// Gets or sets the registration confirmation message to display.
        /// </summary>
        /// <value>
        /// The registration confirmation message to display.
        /// </value>
        public string ConfirmationMessage
        {
            get; set;
        }

        #endregion properties
    }
}