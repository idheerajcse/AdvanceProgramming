﻿// <copyright file="LoginViewModel.cs" company="TECO Services Inc.">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <authors>Enterprise & Business Solutions</authors>
// <date>2017-11-03</date>
namespace TECO.CSSP.Portal.Web.Areas.AgencyPortal.Models.Account
{
    using Common.Mvc.ViewModel;
    using Web.Models.Shared;

    /// <summary>
    /// View model for Login.
    /// </summary>
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1726:UsePreferredTerms", MessageId = "Login", Justification = "As defined by ASP.NET Identity.")]
    public class LoginViewModel : ViewModelBase
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="LoginViewModel"/> class.
        /// </summary>
        public LoginViewModel()
        {
            MaintenanceWindows = new MaintenanceWindowViewModel();
            Credentials = new CredentialsTemplate();
        }

        #endregion

        #region Properties
        /// <summary>
        /// Gets or sets Credentials.
        /// </summary>
        /// <value>
        /// The credentials.
        /// </value>
        public CredentialsTemplate Credentials { get; set; }

        /// <summary>
        /// Gets or sets Maintenance Windows.
        /// </summary>
        /// <value>
        /// The maintenance windows.
        /// </value>
        public MaintenanceWindowViewModel MaintenanceWindows { get; set; }
        #endregion
    }
}