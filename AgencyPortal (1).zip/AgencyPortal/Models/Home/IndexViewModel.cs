﻿// <copyright file="IndexViewModel.cs" company="TECO Services Inc.">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <authors>Enterprise & Business Solutions</authors>
// <date>2017-10-26</date>
namespace TECO.CSSP.Portal.Web.Areas.AgencyPortal.Models.Home
{
    using System.ComponentModel.DataAnnotations;
    using Common.Mvc.ViewModel;
    using Resource;
    using TECO.CSSP.Portal.Web.Models.Shared;

    /// <summary>
    /// View model for index of Agency User.
    /// </summary>
    public class IndexViewModel : ViewModelBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="IndexViewModel"/> class.
        /// </summary>
        public IndexViewModel()
        {
            MaintenanceWindows = new MaintenanceWindowViewModel();
        }

        /// <summary>
        /// Gets or sets the Contract Account Number.
        /// </summary>
        /// <value>
        /// The Contract Account Number.
        /// </value>
        [Required(ErrorMessageResourceName = "RequiredError", ErrorMessageResourceType = typeof(Resource.Common.Responses))]
        [RegularExpression(Resource.Account.Constants.ForgotUserNameContractAccountRegex, ErrorMessageResourceName = "ForgotUserNameContractAccountNumberLengthError", ErrorMessageResourceType = typeof(Resource.Account.Responses))]
        [Display(Name = "AccountNumberLabel", ResourceType = typeof(Resource.Common.UI))]
        public string ContractAccountNo
        {
            get; set;
        }

        /// <summary>
        /// Gets or sets a value indicating whether the user has received authorization from the customer.
        /// </summary>
        /// <value>
        /// Received customer authorization, checkbox must be checked yes.
        /// </value>
        [Range(typeof(bool), "true", "true", ErrorMessageResourceName = "ContractAccountSearch_CheckingAgreement_Error_Required", ErrorMessageResourceType = typeof(Resources))]
        [Display(Name = "ContractAccountSearch_HasCustomerAuthorization", ResourceType = typeof(Resources))]
        public bool HasCustomerAuthorization { get; set; }

        /// <summary>
        /// Gets or sets the maintenance windows.
        /// </summary>
        /// <value>
        /// The maintenance windows.
        /// </value>
        public MaintenanceWindowViewModel MaintenanceWindows { get; set; }
    }
}