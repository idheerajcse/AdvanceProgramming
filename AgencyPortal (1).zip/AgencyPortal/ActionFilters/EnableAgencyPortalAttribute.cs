﻿// <copyright file="EnableAgencyPortalAttribute.cs" company="TECO Services Inc.">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <authors>Enterprise & Business Solutions</authors>
// <date>2017-10-25</date>
namespace TECO.CSSP.Portal.Web.Areas.AgencyPortal.ActionFilters
{
    using System;
    using System.Net;
    using System.Web.Mvc;
    using Common;
    using Common.Logging.AppInsights;

    /// <summary>
    /// The Enable Agency Portal Attribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, Inherited = true, AllowMultiple = true)]
    public sealed class EnableAgencyPortalAttribute : ActionFilterAttribute
    {
        /// <summary>
        /// Gets or sets the application insights logger
        /// </summary>
        public IAppInsightsLogger AppInsightsLogger { get; set; }

        /// <summary>
        /// Called by the ASP.NET MVC framework before the action method executes.
        /// </summary>
        /// <param name="filterContext">The filter context.</param>
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            Validate.NotNull(filterContext);

            try
            {
                bool isEnableAgencyPortal = Settings.AgencyPortal.EnableAgencyPortal;
                if (!isEnableAgencyPortal)
                {
                    int statusCode = (int)HttpStatusCode.Forbidden;
                    filterContext.Result = new HttpStatusCodeResult(statusCode);
                }

                base.OnActionExecuting(filterContext);
            }
            catch (Exception ex)
            {
                AppInsightsLogger.Error(ex, "Error executing filter to check if enable agency portal. Exception: {0}", ex.Message);
                throw new RuntimeException("Unable to execute filter to check if enable agency portal.", ex);
            }
        }
    }
}