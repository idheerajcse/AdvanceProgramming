﻿// <copyright file="ContractAccountController.cs" company="TECO Services Inc.">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <authors>Enterprise & Business Solutions</authors>
// <date>2017-10-27</date>
namespace TECO.CSSP.Portal.Web.Areas.AgencyPortal.Controllers
{
    using System;
    using System.Threading.Tasks;
    using System.Web.Mvc;
    using ActionFilters;
    using Common.Logging.AppInsights;
    using Models.Home;
    using TECO.Common;
    using TECO.CSSP.Portal.Domain.BusinessMasterData;
    using TECO.CSSP.Portal.Web.Areas.AgencyPortal.Models.ContractAccount;

    /// <summary>
    /// Controller for contract account views for Agency Portal.
    /// </summary>
    [EnableAgencyPortal]
    public class ContractAccountController : Controller
    {
        #region Fields

        /// <summary>
        /// The application insights logger
        /// </summary>
        private readonly IAppInsightsLogger appInsightsLogger;

        /// <summary>
        /// The user manager
        /// </summary>
        private readonly IContractAccountManager contractAccountManager;

        /// <summary>
        /// The account manager
        /// </summary>
        private readonly IAccountManager accountManager;

        /// <summary>
        /// The open items manager
        /// </summary>
        private readonly IOpenItemsManager openItemsManager;

        #endregion Fields

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="ContractAccountController"/> class.
        /// </summary>
        /// <param name="contractAccountManager">The Contract AccountManager</param>
        /// <param name="accountManager">The AccountManager</param>
        /// <param name="appInsightsLogger">The Application Insights Logger</param>
        /// <param name="openItemsManager">The Open Items Manager</param>
        public ContractAccountController(IContractAccountManager contractAccountManager, IAccountManager accountManager, IAppInsightsLogger appInsightsLogger, IOpenItemsManager openItemsManager)
        {
            this.accountManager = accountManager;
            this.appInsightsLogger = appInsightsLogger;
            this.contractAccountManager = contractAccountManager;
            this.openItemsManager = openItemsManager;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets the user manager.
        /// </summary>
        /// <value>
        /// The user manager.
        /// </value>
        public IContractAccountManager ContractAccountManager
        {
            get
            {
                return this.contractAccountManager;
            }
        }

        /// <summary>
        /// Gets the account manager.
        /// </summary>
        /// <value>
        /// The account manager.
        /// </value>
        public IAccountManager AccountManager
        {
            get
            {
                return this.accountManager;
            }
        }

        /// <summary>
        /// Gets the application insights logger.
        /// </summary>
        /// <value>
        /// The application insights logger.
        /// </value>
        public IAppInsightsLogger AppInsightsLogger
        {
            get
            {
                return this.appInsightsLogger;
            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// Get the contract account details to display.
        /// </summary>
        /// <remarks>
        /// POST: AgencyPortal/ContractAccount/Search
        /// </remarks>
        /// <param name="indexViewModel">The model.</param>
        /// <returns>Action result</returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Search(Models.Home.IndexViewModel indexViewModel)
        {
            if (!Request.IsAuthenticated)
            {
                return RedirectToAction("Login", "Account");
            }

            Validate.NotNull(indexViewModel);

            if (!indexViewModel.IsValid)
            {
                return View("../Home/Index", indexViewModel);
            }

            var contractAccount = await ContractAccountManager.GetContractAccountByContractAccountIdAsync(indexViewModel.ContractAccountNo);
            if (contractAccount == null || contractAccount.ContractAccountId == null)
            {
                indexViewModel.ControllerActionResponse.MessageType = Common.Mvc.ViewModel.ControllerActionResponseType.Info;
                indexViewModel.ControllerActionResponse.Message = "Contract Account not found.";
                return View("../Home/Index", indexViewModel);
            }

            var account = await AccountManager.GetAccountByAccountIdAsync(contractAccount.AccountId);
            if (account == null)
            {
                indexViewModel.ControllerActionResponse.MessageType = Common.Mvc.ViewModel.ControllerActionResponseType.Info;
                indexViewModel.ControllerActionResponse.Message = "Account associated to Contract Account not found.";
                return View("../Home/Index", indexViewModel);
            }

            ContractAccountDetailViewModel model = new ContractAccountDetailViewModel();

            model.Name = account.FullName;
            model.AccountNo = contractAccount.ContractAccountId;
            model.Address = contractAccount.PremiseAddress;
            model.TotalAmountDue = contractAccount.TotalAmount;
            model.CurrentMonthChargesDue = contractAccount.CurrentBalanceDueDate ?? DateTime.MinValue;
            model.PhoneNumber = await account.GetStandardPhoneAsync();
            model.OpenItemsViewModel = new OpenItemsViewModel();
            var data = await openItemsManager.GetOpenItemsByContractAccountIdAsync(contractAccount.ContractAccountId);
            model.OpenItemsViewModel.ShowPagination = false;
            if (data != null)
            {
                foreach (var openItem in data)
                {
                    model.OpenItemsViewModel.TableData.Add(openItem);
                }
            }

            return View("Index", model);
        }

        #endregion
    }
}