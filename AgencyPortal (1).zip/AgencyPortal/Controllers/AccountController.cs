﻿// <copyright file="AccountController.cs" company="TECO Services Inc.">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <authors>Enterprise & Business Solutions</authors>
// <date>2017-10-09</date>
namespace TECO.CSSP.Portal.Web.Areas.AgencyPortal.Controllers
{
    using System;
    using System.Linq;
    using System.Net;
    using System.Text;
    using System.Threading.Tasks;
    using System.Web.Mvc;
    using Common.Logging.AppInsights;
    using Extensions;
    using Microsoft.Owin.Security;
    using TECO.Common;
    using TECO.Common.Mvc.ViewModel;
    using TECO.CSSP.Portal.Domain.BusinessMasterData;
    using TECO.CSSP.Portal.Domain.Identity;
    using TECO.CSSP.Portal.Resource;
    using TECO.CSSP.Portal.Web.Areas.AgencyPortal.ActionFilters;
    using TECO.CSSP.Portal.Web.Areas.AgencyPortal.Models.Account;
    using Web.ActionFilters;
    using Web.Models.Shared;

    /// <summary>
    /// Controller for account views for Agency Portal.
    /// </summary>
    [EnableAgencyPortal]
    public class AccountController : Controller
    {
        #region Fields

        /// <summary>
        /// The application insights logger
        /// </summary>
        private readonly IAppInsightsLogger appInsightsLogger;

        /// <summary>
        /// The agency invite manager
        /// </summary>
        private readonly IAgencyInviteManager agencyInviteManager;

        /// <summary>
        /// The authentication manager
        /// </summary>
        private readonly IAuthenticationManager authenticationManager;

        /// <summary>
        /// The sign in manager
        /// </summary>
        private readonly IApplicationSignInManager signInManager;

        /// <summary>
        /// The user manager
        /// </summary>
        private readonly IApplicationUserManager userManager;

        /// <summary>
        /// The maintenance window manager
        /// </summary>
        private readonly IMaintenanceWindowManager maintenanceWindowManager;

        #endregion Fields

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="AccountController" /> class.
        /// </summary>
        /// <param name="userManager">The user manager.</param>
        /// <param name="signInManager">The sign in manager.</param>
        /// <param name="authenticationManager">The authentication manager.</param>
        /// <param name="appInsightsLogger">The application insights logger.</param>
        /// <param name="maintenanceWindowManager">The maintenance window manager.</param>
        /// <param name="agencyInviteManager">The agency invite manager.</param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1704:IdentifiersShouldBeSpelledCorrectly", MessageId = "auth", Justification = "As defined by ASP.NET Identity.")]
        public AccountController(IApplicationUserManager userManager, IApplicationSignInManager signInManager, IAuthenticationManager authenticationManager, IAppInsightsLogger appInsightsLogger, IMaintenanceWindowManager maintenanceWindowManager, IAgencyInviteManager agencyInviteManager)
        {
            this.userManager = userManager;
            this.signInManager = signInManager;
            this.authenticationManager = authenticationManager;
            this.appInsightsLogger = appInsightsLogger;
            this.maintenanceWindowManager = maintenanceWindowManager;
            this.agencyInviteManager = agencyInviteManager;
        }

        #endregion Constructors

        #region Properties

        /// <summary>
        /// Gets the application insights logger.
        /// </summary>
        /// <value>
        /// The application insights logger.
        /// </value>
        public IAppInsightsLogger AppInsightsLogger
        {
            get
            {
                return this.appInsightsLogger;
            }
        }

        /// <summary>
        /// Gets the agency invite manager.
        /// </summary>
        /// <value>
        /// The agency invite manager.
        /// </value>
        public IAgencyInviteManager AgencyInviteManager
        {
            get
            {
                return this.agencyInviteManager;
            }
        }

        /// <summary>
        /// Gets the authentication manager.
        /// </summary>
        /// <value>
        /// The authentication manager.
        /// </value>
        public IAuthenticationManager AuthenticationManager
        {
            get
            {
                return this.authenticationManager;
            }
        }

        /// <summary>
        /// Gets the sign in manager.
        /// </summary>
        /// <value>
        /// The sign in manager.
        /// </value>
        public IApplicationSignInManager SignInManager
        {
            get
            {
                return this.signInManager;
            }
        }

        /// <summary>
        /// Gets the user manager.
        /// </summary>
        /// <value>
        /// The user manager.
        /// </value>
        public IApplicationUserManager UserManager
        {
            get
            {
                return this.userManager;
            }
        }

        /// <summary>
        /// Gets the maintenance window manager.
        /// </summary>
        /// <value>
        /// The maintenance window manager.
        /// </value>
        public IMaintenanceWindowManager MaintenanceWindowManager
        {
            get
            {
                return this.maintenanceWindowManager;
            }
        }

        #endregion Properties

        #region Methods

        /// <summary>
        /// Registers this instance.
        /// </summary>
        /// <remarks>
        /// GET: /Account/Register
        /// </remarks>
        /// <param name="agencyInviteId">The agency invite id.</param>
        /// <returns>Action result</returns>
        [AllowAnonymous]
        public async Task<ActionResult> Register(string agencyInviteId)
        {
            try
            {
                if (MaintenanceWindowManager.IsActiveMaintenanceWindow(System.Web.HttpContext.Current.Request.Url.Host))
                {
                    return RedirectToAction("Login", "Account");
                }

                if (string.IsNullOrEmpty(agencyInviteId))
                {
                    AppInsightsLogger.Error(Resources.AgencyInviteId_NullOrEmpty);
                    return new HttpStatusCodeResult(400);
                }

                Guid parsedGuid;
                bool isGuid = Guid.TryParse(agencyInviteId, out parsedGuid);
                if (!isGuid)
                {
                    AppInsightsLogger.Error(Resources.AgencyInviteId_Invalid, agencyInviteId);
                    return new HttpStatusCodeResult(400);
                }

                var agencyInvite = await AgencyInviteManager.GetAgencyInviteByIdAsync(Guid.Parse(agencyInviteId));
                if (agencyInvite == null)
                {
                    AppInsightsLogger.Error(Resources.AgencyInvite_NotFoundForAgencyInviteId, agencyInviteId);
                    return new HttpStatusCodeResult(404, Resources.AgencyInvite_NotFound);
                }

                RegisterViewModel model = new RegisterViewModel();
                model.AgencyInviteId = agencyInvite.AgencyInviteId;
                model.FirstName = agencyInvite.FirstName;
                model.LastName = agencyInvite.LastName;

                if (agencyInvite.AgencyInviteStatus != AgencyInviteStatus.Active)
                {
                    switch (agencyInvite.AgencyInviteStatus)
                    {
                        case AgencyInviteStatus.Expired:
                            {
                                model.ControllerActionResponse.Message = Resources.AgencyInvite_Expired;
                                model.ControllerActionResponse.MessageType = ControllerActionResponseType.Error;
                                return View(model);
                            }

                        case AgencyInviteStatus.Registered:
                            {
                                model.ControllerActionResponse.Message = Resources.AgencyInvite_Registered;
                                model.ControllerActionResponse.MessageType = ControllerActionResponseType.Info;
                                return View(model);
                            }

                        case AgencyInviteStatus.Cancelled:
                            {
                                model.ControllerActionResponse.Message = Resources.AgencyInvite_Cancelled;
                                model.ControllerActionResponse.MessageType = ControllerActionResponseType.Info;
                                return View(model);
                            }

                        default:
                            {
                                model.ControllerActionResponse.Message = Resources.AgencyInvite_StatusNotFound;
                                model.ControllerActionResponse.MessageType = ControllerActionResponseType.Error;
                                return View(model);
                            }
                    }
                }

                return View(model);
            }
            catch (Exception ex)
            {
                AppInsightsLogger.Error(ex, Resources.AgencyUserRegister_UnexpectedError, ex.Message);
                return new HttpStatusCodeResult(500, ex.Message);
            }
        }

        /// <summary>
        /// Registers the specified model.
        /// </summary>
        /// <remarks>
        /// POST: /Account/Register
        /// </remarks>
        /// <param name="model">The model.</param>
        /// <returns>Action result.</returns>
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Register(RegisterViewModel model)
        {
            Validate.NotNull(model);

            try
            {
                if (MaintenanceWindowManager.IsActiveMaintenanceWindow(System.Web.HttpContext.Current.Request.Url.Host))
                {
                    return RedirectToAction("Login", "Account");
                }

                if (ModelState.IsValid)
                {
                    //// Get the AccountId (AgencyId) and other secure information we need in order
                    //// to register and activate the agency user; then, update the agency invite status.
                    var agencyInvite = await AgencyInviteManager.GetAgencyInviteByIdAsync(model.AgencyInviteId);
                    if (agencyInvite == null)
                    {
                        AppInsightsLogger.Error(Resources.AgencyInvite_InformationForAgencyInviteIdNotFound, model.AgencyInviteId);
                        return new HttpStatusCodeResult(404, Resources.AgencyInvite_InformationNotFound);
                    }

                    //// Build the agency user to register and activate.
                    var agencyUser = new ApplicationUser();
                    agencyUser.AccountId = agencyInvite.AgencyId;
                    agencyUser.Email = agencyInvite.EmailAddress;
                    agencyUser.FirstName = agencyInvite.FirstName;
                    agencyUser.LastName = agencyInvite.LastName;
                    agencyUser.PhoneNumber = model.PhoneNumber;
                    agencyUser.UserName = model.UserName;
                    agencyUser.PasswordHash = model.Password;
                    agencyUser.EmailConfirmed = true;
                    agencyUser.ApplicationUserType = ApplicationUserType.Agency;

                    AppInsightsLogger.Verbose(Resource.Resources.Controllers_AccountControllers_AttemptingAgencyUserRegistration, model.UserName, agencyInvite.EmailAddress, model.AgencyInviteId.ToString());

                    //// Register and activate the agency user.
                    var result = await UserManager.RegisterAgencyUserAsync(agencyUser, agencyInvite.RoleId);
                    if (result.Succeeded)
                    {
                        //// Update the agency invite record status to registered.
                        agencyInvite.AgencyInviteStatus = AgencyInviteStatus.Registered;
                        var updateAgencyInviteStatus = await AgencyInviteManager.SaveAgencyInviteAsync(agencyInvite);
                        if (updateAgencyInviteStatus == null)
                        {
                            AppInsightsLogger.Error("Unable to set Agency Invite Status to registered for AgencyInviteId: {0} after successful registration of agency user: {1}", model.AgencyInviteId.ToString(), model.UserName);
                            model.ControllerActionResponse.Message = Resource.Resources.Common_Error_UnableToCompleteRequest;
                            model.ControllerActionResponse.MessageType = ControllerActionResponseType.Error;
                            return View("Register", model);
                        }

                        AppInsightsLogger.Info(Resource.Resources.Controllers_AccountControllers_AgencyUserRegistrationSuccessful, model.UserName);
                        AppInsightsLogger.TrackEvent(Resources.RegisterAgencyUser);
                        return RedirectToAction("RegisterConfirmation", "Account");
                    }
                    else
                    {
                        if (result.Errors.First().Contains(Resources.IsAlreadyTaken) || result.Errors.First().Equals(Resource.Account.Constants.UserAlreadyExistsError2))
                        {
                            model.ControllerActionResponse.Message = Resource.Resources.Controllers_AccountControllers_UserAlreadyTaken;
                            model.ControllerActionResponse.MessageType = ControllerActionResponseType.Error;
                            AppInsightsLogger.Warning(Resources.AgencyUser_UserName_FailedToRegister, model.UserName, result.Errors.First());
                        }
                        else
                        {
                            switch (result.Errors.First())
                            {
                                case Resource.Account.Constants.UserAlreadyExistsError:
                                    {
                                        model.ControllerActionResponse.Message = Resource.Resources.Controllers_AccountControllers_UserAlreadyRegistered;
                                        model.ControllerActionResponse.MessageType = ControllerActionResponseType.Error;
                                        AppInsightsLogger.Warning(Resources.AgencyUser_UserName_FailedToRegister, model.UserName, result.Errors.First());
                                        break;
                                    }

                                default:
                                    {
                                        model.ControllerActionResponse.Message = Resource.Resources.Common_Error_UnableToCompleteRequest;
                                        model.ControllerActionResponse.MessageType = ControllerActionResponseType.Error;

                                        var sb = new StringBuilder();
                                        result.Errors.ToList().ForEach(e => sb.Append(e + "<br />"));
                                        var errorMessage = sb.ToString();

                                        AppInsightsLogger.Warning(Resources.AgencyUser_UnableToCompleteRegistration, model.UserName, errorMessage);
                                        break;
                                    }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                model.ControllerActionResponse.Message = Resource.Resources.Common_Error_UnableToCompleteRequest;
                model.ControllerActionResponse.MessageType = ControllerActionResponseType.Error;
                AppInsightsLogger.Error(ex, Resource.Resources.Controllers_AccountControllers_AgencyUserRegistrationUnsuccessful, model.UserName);
            }

            // If we got this far, something failed, redisplay form.
            return View("Register", model);
        }

        /// <summary>
        /// Registers the confirmation.
        /// </summary>
        /// <returns>Returns view</returns>
        [AllowAnonymous]
        public ActionResult RegisterConfirmation()
        {
            //// Construct the confirmation message to display on the screen.
            string emailAgencyPortalRegistrationTemplate = TECO.CSSP.Portal.Resource.Resources.Email_AgencyPortalRegistrationConfirmationEmailTemplate;
            string fullPathLoginImage = Domain.Utility.EmailService.Host + TECO.CSSP.Portal.Resource.Resources.Email_AgencyPortalLoginImage;
            string logOnUrl = Domain.Utility.EmailService.Host + Resource.Resources.Email_AgencyPortalRegistration_LoginUrl;
            string agencyPortalRegistrationConfirmationMessage = string.Format(emailAgencyPortalRegistrationTemplate, logOnUrl, fullPathLoginImage);

            RegisterConfirmationViewModel model = new RegisterConfirmationViewModel();
            model.ConfirmationMessage = agencyPortalRegistrationConfirmationMessage;

            return View(model);
        }

        /// <summary>
        /// Logins the specified return URL.
        /// </summary>
        /// <remarks>
        /// GET: /Account/Login
        /// </remarks>
        /// <param name="returnUrl">The return URL.</param>
        /// <returns>Action result.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1726:UsePreferredTerms", MessageId = "Login", Justification = "As defined by ASP.NET Identity.")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1054:UriParametersShouldNotBeStrings", MessageId = "0#", Justification = "As defined by ASP.NET Identity.")]
        [AllowAnonymous]
        [NavigateAuthenticatedUsers]
        public ActionResult Login(string returnUrl)
        {
            var model = new LoginViewModel();

            model.MaintenanceWindows.GetMaintenanceWindows(maintenanceWindowManager);

            ViewBag.ReturnUrl = returnUrl;
            ViewBag.labelColSize = "6";
            ViewBag.remainingColSize = "6";

            return View(model);
        }

        /// <summary>
        /// Logins the specified model.
        /// </summary>
        /// <param name="credentialsModel">The credentials model.</param>
        /// <param name="returnUrl">The return URL.</param>
        /// <returns>
        /// Action result
        /// </returns>
        /// <remarks>
        /// POST: /Account/Login
        /// </remarks>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1726:UsePreferredTerms", MessageId = "Login", Justification = "As defined by ASP.NET Identity.")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1054:UriParametersShouldNotBeStrings", MessageId = "1#", Justification = "As defined by ASP.NET Identity.")]
        [HttpPost]
        [AllowAnonymous]
        [NavigateAuthenticatedUsers]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Login([Bind(Prefix = "Credentials")] CredentialsTemplate credentialsModel, string returnUrl)
        {
            var model = new LoginViewModel();
            model.Credentials = credentialsModel;

            ViewBag.labelColSize = "6";
            ViewBag.remainingColSize = "6";
            try
            {
                if (returnUrl == "/Account/LogOff")
                {
                    returnUrl = string.Empty;
                }

                if (!ModelState.IsValid)
                {
                    return View(model);
                }

                if (MaintenanceWindowManager.IsActiveMaintenanceWindow(System.Web.HttpContext.Current.Request.Url.Host))
                {
                    return RedirectToAction("Login", "Account");
                }

                // Store credentials for NetWeaver Gateway transactions
                var loginCredentials = new NetworkCredential(model.Credentials.UserName, TECO.Common.Security.SecureStringExtensions.ConvertToSecureString(model.Credentials.Password));
                Session[TECO.CSSP.Portal.Web.Controllers.Constants.Credentials] = loginCredentials;

                var result = await SignInManager.SignInAsync(model.Credentials.UserName, model.Credentials.Password, false, shouldLockout: true);
                if (result == null)
                {
                    ModelState.AddModelError(string.Empty, Resource.Resources.Controllers_AccountControllers_CredentialsIncorrect);
                    return View(model);
                }
                else
                {
                    switch (result.ApplicationSignInStatus)
                    {
                        case ApplicationSignInStatus.Success:
                            {
                                MvcApplication.Account = result.Account;

                                if (Url.IsLocalUrl(returnUrl))
                                {
                                    return Redirect(returnUrl);
                                }

                                return RedirectToAction("Index", "Home");
                            }

                        case ApplicationSignInStatus.InvalidUser:
                            {
                                ModelState.AddModelError(string.Empty, Resource.Resources.Controllers_AccountControllers_IncorrectUserName);
                                return View(model);
                            }

                        case ApplicationSignInStatus.EmailNotConfirmed:
                            {
                                ModelState.AddModelError(string.Empty, string.Concat(Resource.Resources.Controllers_AccountControllers_RegistrationIncomplete, Resource.Resources.Account_RegisterConfirmation_Body1));
                                return View(model);
                            }

                        case ApplicationSignInStatus.LockedOut:
                            {
                                return View("Lockout");
                            }

                        case ApplicationSignInStatus.GatewayAuthenticationFailure:
                            {
                                Utilities.SessionHelper.EndSession(this.AuthenticationManager, HttpContext.Session);
                                ModelState.AddModelError(string.Empty, Resource.Resources.Controllers_AccountControllers_UnableToAuthenticate);
                                return View(model);
                            }

                        case ApplicationSignInStatus.Failure:
                        default:
                            {
                                ModelState.AddModelError(string.Empty, Resource.Resources.Controllers_AccountControllers_CredentialsIncorrect);
                                return View(model);
                            }
                    }
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError(string.Empty, Resource.Resources.Controllers_AccountControllers_UnableToAuthenticate);
                AppInsightsLogger.Error(ex, Resource.Resources.Controllers_AccountControllers_UnableToAuthenticate, model.Credentials.UserName);
                return View(model);
            }
        }

        /// <summary>
        /// Logs off the user.
        /// </summary>
        /// <remarks>
        /// POST: /Account/LogOff
        /// </remarks>
        /// <returns>Action result</returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult LogOff()
        {
            this.AppInsightsLogger.TrackEvent("Logoff");
            Session.RemoveAll();
            Utilities.SessionHelper.EndSession(this.AuthenticationManager, HttpContext.Session);
            return RedirectToAction("Index", "Home");
        }
    }

    #endregion Methods
}