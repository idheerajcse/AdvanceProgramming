﻿// <copyright file="CommitmentController.cs" company="TECO Services Inc.">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <authors>Enterprise & Business Solutions</authors>
// <date>2017-11-20</date>
namespace TECO.CSSP.Portal.Web.Areas.AgencyPortal.Controllers
{
    using System;
    using System.Threading.Tasks;
    using System.Web.Mvc;
    using ActionFilters;
    using Common.Logging.AppInsights;
    using TECO.Common;
    using TECO.CSSP.Portal.Domain.BusinessMasterData;
    using TECO.CSSP.Portal.Web.Areas.AgencyPortal.Models.Commitment;
    using TECO.CSSP.Portal.Web.Areas.AgencyPortal.Models.ContractAccount;
    using System.Collections.Generic;

    /// <summary>
    /// Controller for commitment view for Agency Portal.
    /// </summary>
    [EnableAgencyPortal]
    public class CommitmentController : Controller
    {
        #region Fields

        /// <summary>
        /// The application insights logger
        /// </summary>
        private readonly IAppInsightsLogger appInsightsLogger;

        /// <summary>
        /// The user manager
        /// </summary>
        private readonly IContractAccountManager contractAccountManager;

        /// <summary>
        /// The account manager
        /// </summary>
        private readonly IAccountManager accountManager;

        /// <summary>
        /// The date time provider
        /// </summary>
        private readonly IDateTimeProvider dateTimeProvider;

        #endregion Fields

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the<see cref="CommitmentController" /> class.
        /// </summary>
        /// <param name="contractAccountManager">The contract manager.</param>
        /// <param name="accountManager">The contract account manager.</param>
        /// <param name="appInsightsLogger">The App Insight manager.</param>
        /// <param name="dateTimeProvider">The date time provider.</param>
        public CommitmentController(IContractAccountManager contractAccountManager, IAccountManager accountManager, IAppInsightsLogger appInsightsLogger, IDateTimeProvider dateTimeProvider)
        {
            this.contractAccountManager = contractAccountManager;
            this.accountManager = accountManager;
            this.appInsightsLogger = appInsightsLogger;
            this.dateTimeProvider = dateTimeProvider;
        }

        #endregion Constructors

        #region Properties

        /// <summary>
        /// Gets the user manager.
        /// </summary>
        /// <value>
        /// The user manager.
        /// </value>
        public IContractAccountManager ContractAccountManager
        {
            get
            {
                return this.contractAccountManager;
            }
        }

        /// <summary>
        /// Gets the account manager.
        /// </summary>
        /// <value>
        /// The account manager.
        /// </value>
        public IAccountManager AccountManager
        {
            get
            {
                return this.accountManager;
            }
        }

        /// <summary>
        /// Gets the application insights logger.
        /// </summary>
        /// <value>
        /// The application insights logger.
        /// </value>
        public IAppInsightsLogger AppInsightsLogger
        {
            get
            {
                return this.appInsightsLogger;
            }
        }

        /// <summary>
        /// Gets the the date time value.
        /// </summary>
        /// <value>
        /// The date time provider.
        /// </value>
        public IDateTimeProvider DateTimeProvider
        {
            get
            {
                return this.dateTimeProvider;
            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// Cancel commitment.
        /// </summary>
        public static void Cancel()
        {
        }

        /// <summary>
        /// Indexes this instance.
        /// </summary>
        /// <returns>Action result.</returns>
        [HttpGet]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Index()
        {
            return View();
        }

        /// <summary>
        /// Indexes this instance.
        /// </summary>
        /// <param name="contractAccountID">String parameter.</param>
        /// <returns>Action result.</returns>
        [HttpGet]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> CommitmentHistory(string contractAccountID)
        {
            return View();
        }

        /// <summary>
        /// Get the commitment view model for confirmation.
        /// </summary>
        /// <param name="commitmentViewModel">The model.</param>
        /// <returns>Action result</returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Confirm(CommitmentViewModel commitmentViewModel)
        {
            return View();
        }

        /// <summary>
        /// Get the commitment view to create.
        /// </summary>
        /// <param name="contractAccountDetailViewModel">The model.</param>
        /// <returns>Action result</returns>
        [HttpPost]
        public async Task<ActionResult> Create(ContractAccountDetailViewModel contractAccountDetailViewModel)
        {
            if (!Request.IsAuthenticated)
            {
                return RedirectToAction("Login", "Account");
            }

            //// Get Agent data you don't have in the posted model.
            var contractAccount = await contractAccountManager.GetContractAccountByContractAccountIdAsync(contractAccountDetailViewModel.ContractAccountId);
            var account = await AccountManager.GetAccountByAccountIdAsync(contractAccount.AccountId);

            //// Create model you need to display to the user.
            CommitmentViewModel model = new CommitmentViewModel();

            ////model.AgentFirstName = MvcApplication.Account.FullName;
            model.AgencyMemo = string.Empty;
            model.AgentFirstName = account.FirstName;
            model.AgentLastName = account.LastName;
            model.AgentPhoneNumber = contractAccountDetailViewModel.PhoneNumber;
            model.CaseName = string.Empty;
            model.ContractAccount = contractAccountDetailViewModel;
            model.CurrentDate = DateTime.Now;
            //// Need to populate this.
            model.fundingResources = PopulateFundingSources(model);

            model.ContractAccount.ServiceAddress = contractAccountDetailViewModel.ServiceAddress;

            //// These need to be created/summed based on the open items passed in in
            //// contractAccountDetailViewModel.  It's a sum of the commitment amounts.
            //// The sum of the commitment amount entered.
            //// model.TotalCommitment = ?;
            //// The total.
            //// model.TotalPayment = ?;
            model.TotalCommitment = GetCommitmentAmount(model);

            return View(model);
        }

        /// <summary>
        /// Get the commitment view to create.
        /// </summary>
        /// <param name="commitmentViewModel">The model.</param>
        /// <returns>Action result</returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(CommitmentViewModel commitmentViewModel)
        {
            if (!Request.IsAuthenticated)
            {
                return RedirectToAction("Login", "Account");
            }

            if (ModelState.IsValid)
            {
                //// Go to the confirmation screen.

                /*
                CommitmentViewModel model = new CommitmentViewModel();
                model.AgentFirstName = commitmentViewModel.AgentFirstName;
                model.AgentLastName = commitmentViewModel.AgentLastName;
                model.AgentPhoneNumber = commitmentViewModel.AgentPhoneNumber;
                model.CaseName = commitmentViewModel.CaseName;
                model.ContractAccount = commitmentViewModel.ContractAccount;
                model.CurrentDate = commitmentViewModel.CurrentDate;
                model.SelectedFundingSource = commitmentViewModel.SelectedFundingSource;
                model.ContractAccount.ServiceAddress = commitmentViewModel.ServiceAddress;
                model.TotalCommitment = commitmentViewModel.TotalCommitment;
                model.TotalPayment = commitmentViewModel.TotalPayment;
                model.AgencyMemo = commitmentViewModel.AgencyMemo;
                ////model = commitmentViewModel;
                */
            }

            return View();
        }

        /// <summary>
        /// Get the commitment previous screen.
        /// </summary>
        /// <returns>Action result</returns>
        [HttpGet]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Previous()
        {
            return View();
        }

        /// <summary>
        /// Get the funding source details.
        /// </summary>
        /// <returns>Funding Source</returns>
        public static IList<FundingResource> PopulateFundingSources( CommitmentViewModel model)
        {
            IList<FundingResource> LstFundingResource = new List<FundingResource>();
            if (model!= null)
            {
                    foreach (FundingResource fundingResource in model.FundingResources)
                    {
                        LstFundingResource.Add(fundingResource);
                    }
            }
            return LstFundingResource;
        }


        #endregion
    }
}