﻿// <copyright file="AgencyInviteController.cs" company="TECO Services Inc.">
// Copyright (c) 2016 All Rights Reserved
// </copyright>
// <authors>Enterprise & Business Solutions</authors>
// <date>2017-10-16</date>
namespace TECO.CSSP.Portal.Web.Areas.AgencyPortal.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using System.Web;
    using System.Web.Mvc;
    using ActionFilters;
    using Domain.Identity;
    using Domain.Utility;
    using TECO.Common;
    using TECO.Common.Logging.AppInsights;
    using TECO.Common.Mvc.ActionFilters;
    using TECO.Common.Mvc.ViewModel;
    using TECO.CSSP.Portal.Domain.BusinessMasterData;
    using TECO.CSSP.Portal.Web.Areas.AgencyPortal.Models.AgencyInvite;
    using TECO.CSSP.Portal.Web.Extensions;   

    ////using TECO.CSSP.Portal.Web.Areas.AgencyPortal.Extensions;

    /// <summary>
    /// Handles the Agency Invite
    /// </summary>
    /// <seealso cref="System.Web.Mvc.Controller" />
    [EnableAgencyPortal]
    public class AgencyInviteController : Controller
    {
        #region Fields

        /// <summary>
        /// The application insights logger
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields", Justification = "Not Used yet.  Will be needed")]
        private readonly IAppInsightsLogger appInsightsLogger;

        /// <summary>
        /// The agency invite manager
        /// </summary>
        private readonly IAgencyInviteManager agencyInviteManager;

        /// <summary>
        /// The Application Role manager
        /// </summary>
        private readonly IApplicationRoleManager applicationRoleManager;

        #endregion Fields

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="AgencyInviteController"/> class.
        /// </summary>
        /// <param name="appInsightsLogger">The application insights logger.</param>
        /// <param name="agencyInviteManager">The agency invite manager.</param>
        /// <param name="applicationRoleManager">The application role manager.</param>
        public AgencyInviteController(IAppInsightsLogger appInsightsLogger, IAgencyInviteManager agencyInviteManager, IApplicationRoleManager applicationRoleManager)
        {
            this.appInsightsLogger = appInsightsLogger;
            this.agencyInviteManager = agencyInviteManager;
            this.applicationRoleManager = applicationRoleManager;
        }

        #endregion Constructors

        #region Methods

        /// <summary>
        /// Indexes this instance.
        /// </summary>
        /// <returns>List of Agency Invites</returns>      
        [HttpGet]
        public ActionResult Index()
        {
            var model = new IndexViewModel();

            model.ControllerActionResponse = (ControllerActionResponse)TempData["controllerActionResponse"];

            var query = agencyInviteManager.GetAgencyInvitesByAgencyId(MvcApplication.Account.AccountId);

            query = model.ProcessSortPage(query);

            foreach (var ag in query.ToList())
            {
                model.TableData.Add(ag);
            }

            return View(model);
        }

        /// <summary>
        /// Creates this instance.
        /// </summary>
        /// <returns>The Create Agency Invite view
        /// </returns>
        [HttpGet]
        public ActionResult Create()
        {
            var model = new AgencyInviteViewModel();
            ////model.AgencyInviteId = Guid.NewGuid();
            model.AgencyId = MvcApplication.Account.AccountId;
            ////model.CreatedDate = DateTime.Now;
            model.AddRoles(applicationRoleManager);
            return View(model);
        }

        /// <summary>
        /// Creates the specified model.
        /// </summary>
        /// <param name="model">The model.</param>
        /// <returns>Returns Create view</returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(AgencyInviteViewModel model)
        {
            Validate.NotNull(model);

            if (ModelState.IsValid)
            {
                if (await agencyInviteManager.SaveAgencyInviteAsync(model.ToDomainModel()) == null)
                {
                    model.ControllerActionResponse = new ControllerActionResponse()
                    {
                        MessageType = ControllerActionResponseType.Error,
                        Message = Resource.AgencyPortal.AgencyInvite.Strings.Save_Failed
                    };

                    return View(model);
                }

                model.ControllerActionResponse = new ControllerActionResponse()
                {
                    Message = Resource.AgencyPortal.AgencyInvite.Strings.Save_Success,
                    MessageType = ControllerActionResponseType.Success
                };
                               
                TempData["controllerActionResponse"] = model.ControllerActionResponse;

                return RedirectToAction("Index", new { Id = model.AgencyId });
            }

            return View(model);
        }

        /// <summary>        /// Details the specified identifier.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns>The Details Page</returns>
        [HttpGet]
        public ActionResult Details(Guid id)
        {
            if (id == null)
            {
                return RedirectToAction("Index");
            }

            var model = new AgencyInviteViewModel();

            model = (from ag in agencyInviteManager.GetAllAgencyInvites where ag.AgencyInviteId == id select ag).FirstOrDefault().ToViewModel();
            var roleId = model.RoleId;
            var role = applicationRoleManager.GetRoles().Where(r => r.Id == roleId).SingleOrDefault();
            model.RoleName = role.Name;
            return View(model);
        }

        /// <summary>
        /// Deletes the specified identifier.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <param name="returnUrl">The return URL.</param>
        /// <returns>
        /// The Delete View
        /// </returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1054:UriParametersShouldNotBeStrings", MessageId = "1#", Justification = "Needed for return Url parameter")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1026:DefaultParametersShouldNotBeUsed", Justification = "Default URL to be specified")]
        [HttpGet]
        public ActionResult Delete(Guid id, string returnUrl = "/AgencyPortal/AgencyInvite")
        {
            var model = new AgencyInviteViewModel();
            ViewBag.Title = TECO.CSSP.Portal.Resource.AgencyPortal.AgencyInvite.Strings.Delete_Page_Title;
            model.ReturnUrl = returnUrl;

            model.ControllerActionResponse = (ControllerActionResponse)TempData["controllerActionResponse"];
            model = (from ag in agencyInviteManager.GetAllAgencyInvites where ag.AgencyInviteId == id select ag).FirstOrDefault().ToViewModel();

            return View(model);
        }

        /// <summary>
        /// Deletes the confirmed.
        /// </summary>
        /// <param name="model">The model.</param>
        /// <returns>Deleted record</returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> DeleteConfirmed(AgencyInviteViewModel model)
        {
            Validate.NotNull(model);

            if (await agencyInviteManager.DeleteAgencyInviteAsync(model.ToDomainModel()))
            {
                model.ControllerActionResponse = new ControllerActionResponse()
                {
                    Message = Resource.AgencyPortal.AgencyInvite.Strings.Delete_Success,
                    MessageType = ControllerActionResponseType.Success
                };

                TempData["controllerActionResponse"] = model.ControllerActionResponse;

                return RedirectToAction("Index");
            }
            else
            {
                model.ControllerActionResponse = new ControllerActionResponse()
                {
                    Message = Resource.AgencyPortal.AgencyInvite.Strings.Delete_Failure,
                    MessageType = ControllerActionResponseType.Error
                };

                TempData["controllerActionResponse"] = model.ControllerActionResponse;

                return View("Delete", model.AgencyInviteId);
            }
        }

        #endregion Methods
    }
}