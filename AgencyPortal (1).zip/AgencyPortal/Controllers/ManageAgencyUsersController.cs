﻿// <copyright file="ManageAgencyUsersController.cs" company="TECO Services Inc.">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <authors>Enterprise & Business Solutions</authors>
// <date>2017-10-16</date>

namespace TECO.CSSP.Portal.Web.Areas.AgencyPortal.Controllers
{
    using System.Linq;
    using System.Text.RegularExpressions;
    using System.Threading.Tasks;
    using System.Web.Mvc;
    using Common;
    using Common.Logging.AppInsights;
    using Common.Mvc.ViewModel;
    using Domain.Identity;
    using Extensions;
    using Models.ManageAgencyUsers;
    using TECO.CSSP.Portal.Web.Areas.AgencyPortal.ActionFilters;

    /// <summary>
    /// The controller for managing agency users.
    /// </summary>
    /// <seealso cref="System.Web.Mvc.Controller" />
    [EnableAgencyPortal]
    public class ManageAgencyUsersController : Controller
    {
        #region Fields

        /// <summary>
        /// The application insights logger
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields", Justification = "Controller not built yet")]
        private readonly IAppInsightsLogger appInsightsLogger;

        /// <summary>
        /// The user manager
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields", Justification = "Controller not built yet")]
        private readonly IApplicationUserManager applicationUserManager;

        #endregion Fields

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="ManageAgencyUsersController"/> class.
        /// </summary>
        /// <param name="appInsightsLogger">The application insights logger.</param>
        /// <param name="applicationUserManager">The application user manager.</param>
        public ManageAgencyUsersController(IAppInsightsLogger appInsightsLogger, IApplicationUserManager applicationUserManager)
        {
            this.appInsightsLogger = appInsightsLogger;
            this.applicationUserManager = applicationUserManager;
        }

        #endregion Constructors

        #region Methods

        /// <summary>
        /// Indexes this instance.
        /// </summary>
        /// <returns>
        /// The View
        /// </returns>
        [HttpGet]
        public ActionResult Index()
        {
            var model = Session["UserListViewModel"] == null ? new IndexViewModel() : (IndexViewModel)Session["UserListViewModel"];
            model.ControllerActionResponse = (ControllerActionResponse)TempData["ControllerActionResponse"];

            var query = applicationUserManager.GetAgencyUsersByAccountId(MvcApplication.Account.AccountId);

            query = model.ProcessFilter(query);

            query = model.ProcessSortPage(query);

            foreach (var u in query.ToList())
            {
                model.TableData.Add(u.ToUserViewModel());
            }

            return View(model);
        }

        /// <summary>
        /// Indexes the specified model.
        /// </summary>
        /// <param name="model">The model.</param>
        /// <returns>A filtered view or redirect</returns>
        [HttpPost]
        public ActionResult Index(IndexViewModel model)
        {
            Validate.NotNull(model);

            if (model.EventCommand == "selection")
            {
                Session["UserListViewModel"] = model;
                return RedirectToAction("Detail", new { id = model.SelectedId });
            }

            var query = applicationUserManager.GetAgencyUsersByAccountId(MvcApplication.Account.AccountId);

            query = model.ProcessFilter(query);

            query = model.ProcessSortPage(query);

            foreach (var u in query.ToList())
            {
                model.TableData.Add(u.ToUserViewModel());
            }

            return View(model);
        }

        /// <summary>
        /// Details the specified identifier.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns>The Detail view</returns>
        [HttpGet]
        public async Task<ActionResult> Detail(string id)
        {
            if (id == null)
            {
                return RedirectToAction("Index");
            }

            UserViewModel model = (await applicationUserManager.FindByNameAsync(id))?.ToUserViewModel();
            if (model == null)
            {
                return RedirectToAction("Index");
            }

            model.ControllerActionResponse = (ControllerActionResponse)TempData["ControllerActionResponse"];
            model.SelectedId = id;

            return View(model);
        }

        /// <summary>
        /// Edits the specified identifier.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns>
        /// The Edit User View
        /// </returns>
        [HttpGet]
        public async Task<ActionResult> Edit(string id)
        {
            if (id == null)
            {
                return RedirectToAction("Index");
            }

            UserViewModel model = (await applicationUserManager.FindByNameAsync(id)).ToUserViewModel();
            if (model == null)
            {
                return RedirectToAction("Index");
            }

            model.ControllerActionResponse = (ControllerActionResponse)TempData["controllerActionResponse"];
            model.SelectedId = id;

            return View(model);
        }

        /// <summary>
        /// Edits the specified model.
        /// </summary>
        /// <param name="model">The model.</param>
        /// <returns>Saves the user and returns status message</returns>
        [HttpPost]
        public async Task<ActionResult> Edit(UserViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var numberFilter = new Regex(@"[^\d]");

            var applicationUser = await applicationUserManager.FindByNameAsync(model.UserName);
            applicationUser.FirstName = model.FirstName;
            applicationUser.LastName = model.LastName;
            applicationUser.Email = model.Email;
            applicationUser.PhoneNumber = numberFilter.Replace(model.PhoneNumber, string.Empty);

            var result = await applicationUserManager.UpdateAsync(applicationUser);

            if (!result.Succeeded)
            {
                model.ControllerActionResponse.MessageType = ControllerActionResponseType.Error;
                model.ControllerActionResponse.Message = string.Format(Resource.AgencyPortal.ManageAgencyUsers.Edit.Responses.SaveFailure, model.UserName);
                return View(model);
            }

            model.ControllerActionResponse.MessageType = ControllerActionResponseType.Success;
            model.ControllerActionResponse.Message = string.Format(Resource.AgencyPortal.ManageAgencyUsers.Edit.Responses.SaveSuccess, model.UserName);
            TempData["ControllerActionResponse"] = model.ControllerActionResponse;
            return RedirectToAction("Detail", new { @id = model.UserName });
        }
        #endregion Methods
    }
}