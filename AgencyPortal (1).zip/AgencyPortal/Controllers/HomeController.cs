﻿// <copyright file="HomeController.cs" company="TECO Services Inc.">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <authors>Enterprise & Business Solutions</authors>
// <date>2017-10-26</date>
namespace TECO.CSSP.Portal.Web.Areas.AgencyPortal.Controllers
{
    using System.Web.Mvc;
    using ActionFilters;
    using Extensions;
    using Models.Home;
    using TECO.Common.Logging.AppInsights;
    using TECO.CSSP.Portal.Domain.BusinessMasterData;

    /// <summary>
    /// Controller for home views for Agency Portal.
    /// </summary>
    [EnableAgencyPortal]
    public class HomeController : Controller
    {
        #region Fields

        /// <summary>
        /// The application insights logger
        /// </summary>
        private readonly IAppInsightsLogger appInsightsLogger;

        /// <summary>
        /// The maintenance window manager
        /// </summary>
        private readonly IMaintenanceWindowManager maintenanceWindowManager;

        #endregion Fields

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="HomeController" /> class.
        /// </summary>
        /// <param name="appInsightsLogger">The authentication manager.</param>
        /// <param name="maintenanceWindowManager">The maintenance window manager.</param>
        public HomeController(IAppInsightsLogger appInsightsLogger, IMaintenanceWindowManager maintenanceWindowManager)
        {
            this.appInsightsLogger = appInsightsLogger;
            this.maintenanceWindowManager = maintenanceWindowManager;
        }

        #endregion Constructors

        #region Properties

        /// <summary>
        /// Gets the application insights logger.
        /// </summary>
        /// <value>
        /// The application insights logger.
        /// </value>
        public IAppInsightsLogger AppInsightsLogger
        {
            get
            {
                return this.appInsightsLogger;
            }
        }

        /// <summary>
        /// Gets the maintenance window manager.
        /// </summary>
        /// <value>
        /// The maintenance window manager.
        /// </value>
        public IMaintenanceWindowManager MaintenanceWindowManager
        {
            get
            {
                return this.maintenanceWindowManager;
            }
        }

        #endregion Properties

        /// <summary>
        /// Indexes this instance.
        /// </summary>
        /// <remarks>
        /// /// GET: AgencyPortal/Home
        /// </remarks>
        /// <returns>Action result.</returns>
        [AllowAnonymous]
        public ActionResult Index()
        {
            if (!Request.IsAuthenticated || MaintenanceWindowManager.IsActiveMaintenanceWindow(System.Web.HttpContext.Current.Request.Url.Host))
            {
                return RedirectToAction("Login", "Account");
            }

            IndexViewModel model = new IndexViewModel();
            model.MaintenanceWindows.GetMaintenanceWindows(maintenanceWindowManager);

            return View(model);
        }
    }
}