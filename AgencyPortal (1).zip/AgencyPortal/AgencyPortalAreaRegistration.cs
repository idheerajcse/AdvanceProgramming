﻿// <copyright file="AgencyPortalAreaRegistration.cs" company="TECO Services Inc.">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <authors>Enterprise & Business Solutions</authors>
// <date>2017-10-09</date>
namespace TECO.CSSP.Portal.Web.Areas.AgencyPortal
{
    using System.Web.Mvc;
    using TECO.Common;

    /// <summary>
    /// The Agency Portal Area Registration class.
    /// </summary>
    public class AgencyPortalAreaRegistration : AreaRegistration
    {
        /// <summary>
        /// Gets the Area Name
        /// </summary>
        public override string AreaName
        {
            get
            {
                return "AgencyPortal";
            }
        }

        /// <summary>
        /// Register the area.
        /// </summary>
        /// <param name="context">The context.</param>
        public override void RegisterArea(AreaRegistrationContext context)
        {
            Validate.NotNull(context);

            //// Added namespace to prevent server 500 error since controllers with
            //// same names exist in Portal.Web and Areas\AgencyPortal.
            context.MapRoute(
                "AgencyPortal_default",
                "AgencyPortal/{controller}/{action}/{id}",
                new { action = "Index", id = UrlParameter.Optional },
                new[] { "TECO.CSSP.Portal.Web.Areas.AgencyPortal.Controllers" });
        }
    }
}